package com.mycompany.jira.plugins.multiplevalues;

import org.junit.Test;

public class MyPluginTest
{
    @Test
    public void testSomething()
    {
    }
}
