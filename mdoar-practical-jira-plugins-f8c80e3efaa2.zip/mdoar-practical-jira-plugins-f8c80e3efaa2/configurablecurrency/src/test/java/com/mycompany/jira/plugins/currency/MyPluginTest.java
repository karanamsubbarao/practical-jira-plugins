package com.mycompany.jira.plugins.currency;

import org.junit.Test;

public class MyPluginTest
{
    @Test
    public void testSomething()
    {
    }
}
