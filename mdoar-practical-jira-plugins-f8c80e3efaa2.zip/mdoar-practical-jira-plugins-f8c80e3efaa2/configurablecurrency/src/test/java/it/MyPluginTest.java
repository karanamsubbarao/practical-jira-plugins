package it;

import org.junit.Test;

public class MyPluginTest
{
    @Test
    public void integrationTest()
    {
    }
}
